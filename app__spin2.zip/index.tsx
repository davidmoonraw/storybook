import React, { useState, useCallback, useMemo } from 'react';
import { createRoot } from 'react-dom/client';

// --- TYPES ---
type View = 'VIEW' | 'NODE_MAP' | 'CHAT' | 'SETTINGS' | 'PROMPT';

interface Node {
  id: string;
  name: string;
  parentId: string | null;
  childrenIds: string[];
  isLocked: boolean; // Sequential child = locked, Iterative parent = unlocked
  creationDate: string;
  promptText: string;
  referenceFiles: (string | { type: 'node', id: string })[];
  imageUrl: string;
}

interface Nodes {
  [key: string]: Node;
}

interface AttachedFile {
  id: string;
  name: string;
  type: 'file' | 'node';
}

// --- MOCK DATA & HELPERS ---
const getNextNodeName = (nodes: Nodes, parentId: string | null): string => {
    if (!parentId) return 'A1';
    const parentNode = nodes[parentId];
    const parentLetter = parentNode.name.charAt(0);
    const parentNum = parseInt(parentNode.name.slice(1), 10);
    if (!parentNode.isLocked) { // Iterative
        const nextChildIndex = parentNode.childrenIds.length;
        const nextLetter = String.fromCharCode(parentLetter.charCodeAt(0) + nextChildIndex + 1);
        return `${nextLetter}${parentNum}`;
    } else { // Sequential
        return `${parentLetter}${parentNum + 1}`;
    }
};

const createDummyImageUrl = () => {
    const colors = ['#7dd3fc', '#f472b6', '#a78bfa', '#fde047', '#6ee7b7'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    return `https://via.placeholder.com/300x400.png?text=NODE&bg=${color.substring(1)}`;
};

// --- STYLES ---
const GlobalStyles = () => (
  <style>{`
    :root {
      --background-color: #000000;
      --panel-bg: #1e1e1e;
      --button-bg: #333333;
      --button-hover-bg: #444444;
      --text-color: #f0f0f0;
      --text-muted: #888888;
      --accent-color: #e50914;
      --accent-hover: #f6121D;
      --border-color: #2c2c2c;
      --green-accent: #4caf50;
      --blue-accent: #2196f3;
    }
    .app-container {
      display: flex;
      height: 100vh;
      background-color: var(--background-color);
      padding: 16px;
      gap: 16px;
    }
    .sidebar {
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding: 16px;
      background-color: var(--panel-bg);
      border-radius: 8px;
    }
    .sidebar-button {
      background-color: var(--button-bg);
      color: var(--text-color);
      border: 1px solid var(--border-color);
      padding: 12px 24px;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.2s;
      font-family: 'Roboto Mono', monospace;
      font-weight: 500;
    }
    .sidebar-button:hover {
      background-color: var(--button-hover-bg);
    }
    .sidebar-button.active {
      background-color: var(--accent-color);
      border-color: var(--accent-color);
    }
    .main-panel {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      background-color: var(--panel-bg);
      border-radius: 8px;
      padding: 20px;
      position: relative;
      overflow: hidden;
    }
    .main-content {
      flex-grow: 1;
      overflow-y: auto;
    }
     .main-content::-webkit-scrollbar {
      width: 8px;
    }
    .main-content::-webkit-scrollbar-track {
      background: var(--button-bg);
      border-radius: 4px;
    }
    .main-content::-webkit-scrollbar-thumb {
      background: var(--text-muted);
      border-radius: 4px;
    }
    .empty-state {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: var(--text-muted);
      font-size: 1.2rem;
    }
  `}</style>
);

// --- SVG ICONS ---
const EyeIcon = ({ toggled }) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>{toggled && <line x1="1" y1="1" x2="23" y2="23"></line>}</svg>;
const LockIcon = ({ locked }) => locked ? <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg> : <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>;
const InfoIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>;
const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>;
const SendIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path></svg>;

// --- COMPONENTS ---

const Card = ({ node, onLockToggle, onDelete, onDetails, onSelect, isEnhanced = false }) => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontWeight: 'bold' }}>{node.name}</span>
            <div 
              onClick={() => onSelect(node.id)}
              style={{ 
                border: '2px solid var(--border-color)', 
                borderRadius: '8px', 
                padding: '8px', 
                backgroundColor: '#2a2a2a', 
                cursor: 'pointer',
                transition: 'border-color 0.2s'
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent-color)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-color)'}
            >
                <img src={node.imageUrl} alt={node.name} style={{ width: '150px', height: '200px', objectFit: 'cover', borderRadius: '4px' }} />
                {isEnhanced && (
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '8px' }}>
                        <div style={{ display: 'flex', gap: '8px' }}>
                            <button onClick={(e) => { e.stopPropagation(); onLockToggle(node.id); }} style={cardButtonStyle}><LockIcon locked={node.isLocked} /></button>
                            <button onClick={(e) => { e.stopPropagation(); onDetails(node.id); }} style={cardButtonStyle}><InfoIcon /></button>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); onDelete(node.id); }} style={{...cardButtonStyle, color: 'var(--accent-color)'}}><TrashIcon /></button>
                    </div>
                )}
            </div>
        </div>
    );
};
const cardButtonStyle = { background: 'none', border: 'none', color: 'var(--text-color)', cursor: 'pointer', padding: '4px' };

const PromptComponent = ({ currentNode, onGenerate, attachedFiles, setAttachedFiles }) => {
    const [prompt, setPrompt] = useState('');
    const [holdFiles, setHoldFiles] = useState(false);

    const handleSend = () => {
        if (!prompt && attachedFiles.length === 0) return;
        onGenerate(prompt, attachedFiles, holdFiles);
        setPrompt('');
        if (!holdFiles) {
            setAttachedFiles([]);
        }
    };
    
    const removeFile = (id) => {
      setAttachedFiles(files => files.filter(f => f.id !== id));
    };

    const addFile = () => {
        const newFile = { id: `file-${Date.now()}`, name: `TREE.JPG`, type: 'file' };
        setAttachedFiles(files => [...files, newFile]);
    }

    return (
        <div style={{ marginTop: 'auto', paddingTop: '16px' }}>
            {currentNode && <div style={{ textAlign: 'right', marginBottom: '8px', color: 'var(--text-muted)' }}>{currentNode.name}</div>}
            <div style={{ 
                background: 'var(--button-bg)', 
                borderRadius: '8px', 
                padding: '8px',
                border: '1px solid var(--border-color)',
                display: 'flex',
                flexDirection: 'column'
            }}>
                {attachedFiles.length > 0 && (
                    <div style={{ paddingBottom: '8px', borderBottom: '1px solid var(--border-color)', marginBottom: '8px' }}>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                            {attachedFiles.map(file => (
                                <div key={file.id} style={{ backgroundColor: '#444', padding: '4px 8px', borderRadius: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                    <span>{file.name}</span>
                                    <button onClick={() => removeFile(file.id)} style={{ background: 'none', border: 'none', color: '#ccc', cursor: 'pointer', padding: 0 }}>&times;</button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                      <button onClick={addFile} style={{ background: 'var(--button-bg)', border: '1px solid var(--border-color)', color: 'var(--text-color)', width: '36px', height: '36px', borderRadius: '50%', cursor: 'pointer' }}>+</button>
                      {attachedFiles.length > 0 && <button onClick={() => setHoldFiles(!holdFiles)} style={{ background: holdFiles ? 'var(--green-accent)' : 'var(--button-bg)', border: '1px solid var(--border-color)', color: 'var(--text-color)', width: '36px', height: '36px', borderRadius: '50%', cursor: 'pointer' }}>||</button>}
                    </div>

                    <input
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder="Type..."
                        style={{
                            flexGrow: 1,
                            background: 'transparent',
                            border: 'none',
                            color: 'var(--text-color)',
                            fontSize: '1rem',
                            outline: 'none',
                        }}
                    />
                    <button onClick={handleSend} style={{ background: 'none', border: 'none', color: 'var(--text-color)', cursor: 'pointer' }}><SendIcon/></button>
                </div>
            </div>
        </div>
    );
};

const ChatComponent = ({ currentNode, nodes }) => {
    const [view, setView] = useState(false);
    
    const chatHistory = useMemo(() => {
      if (!currentNode) return [];
      let history = [];
      let curr = currentNode;
      while (curr) {
        history.unshift(curr);
        curr = curr.parentId ? nodes[curr.parentId] : null;
      }
      return history;
    }, [currentNode, nodes]);

    if (!currentNode) {
        return <div className="empty-state">Nothing to display...</div>;
    }

    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%'}}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <span style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{currentNode.name}</span>
          <button onClick={() => setView(!view)} style={{ background: 'none', border: 'none', color: 'var(--text-color)', cursor: 'pointer' }}>
            <EyeIcon toggled={!view} />
          </button>
        </div>
        <div className="main-content">
          {chatHistory.map(node => (
            <div key={node.id} style={{ marginBottom: '12px' }}>
              <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>
                {view && <span style={{ marginRight: '8px' }}>+</span>}
                {node.promptText || 'Initial text'}
                {view && <span style={{ color: 'var(--text-muted)', marginLeft: '12px' }}>{node.parentId ? nodes[node.parentId].name : ''} &rarr; {node.name}</span>}
              </p>
            </div>
          ))}
        </div>
      </div>
    );
};

const ViewComponent = ({ nodes, currentNodeId, onNodeSelect, onLockToggle, onDelete, onDetails }) => {
  const currentNode = nodes[currentNodeId];

  if (!currentNode) {
    return <div className="empty-state">Nothing to display...</div>;
  }

  // Iterative View
  if (!currentNode.isLocked || currentNode.childrenIds.length > 1) {
    const children = currentNode.childrenIds.map(id => nodes[id]);
    return (
       <div style={{ display: 'flex', gap: '20px', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
         <Card node={currentNode} onSelect={onNodeSelect} isEnhanced={true} onLockToggle={onLockToggle} onDelete={onDelete} onDetails={onDetails} />
         <div style={{width: '2px', height: '300px', backgroundColor: 'var(--border-color)'}}></div>
         <div style={{ display: 'flex', gap: '16px' }}>
           {/* FIX START: Fix type error by providing an explicit type for `child` and handling undefined cases. */}
           {children.map((child: Node | undefined) => {
             if (!child) return null;
             return <Card key={child.id} node={child} onSelect={onNodeSelect} isEnhanced={true} onLockToggle={onLockToggle} onDelete={onDelete} onDetails={onDetails} />;
           })}
           {/* FIX END */}
         </div>
       </div>
    );
  }

  // Sequential View
  const parent = currentNode.parentId ? nodes[currentNode.parentId] : null;
  return (
    <div style={{ display: 'flex', gap: '20px', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
      {parent && <Card node={parent} onSelect={onNodeSelect} isEnhanced={true} onLockToggle={onLockToggle} onDelete={onDelete} onDetails={onDetails} />}
      <Card node={currentNode} onSelect={onNodeSelect} isEnhanced={true} onLockToggle={onLockToggle} onDelete={onDelete} onDetails={onDetails} />
    </div>
  );
};

const NodeMapComponent = ({ nodes, currentNodeId, onNodeSelect }) => {
    if (Object.keys(nodes).length === 0) {
        return <div className="empty-state">Nothing to display...</div>;
    }
    
    const renderNode = (nodeId, level = 0) => {
        const node = nodes[nodeId];
        if (!node) return null;

        return (
            <div key={node.id} style={{ marginLeft: `${level * 40}px`, marginTop: '10px' }}>
                <div 
                    onClick={() => onNodeSelect(node.id)}
                    style={{
                        padding: '8px 12px',
                        background: nodeId === currentNodeId ? 'var(--accent-color)' : 'var(--button-bg)',
                        borderRadius: '4px',
                        display: 'inline-block',
                        cursor: 'pointer',
                        border: '1px solid var(--border-color)'
                    }}>
                    {node.name}
                </div>
                {node.childrenIds.length > 0 && (
                    <div>
                        {node.childrenIds.map(childId => renderNode(childId, level + 1))}
                    </div>
                )}
            </div>
        );
    };

    // FIX START: Fix type errors by explicitly typing `n` as `Node`. This allows accessing `n.parentId` and correctly types `rootNodes`, which in turn fixes the error on `node.id`.
    const rootNodes = Object.values(nodes).filter((n: Node) => n.parentId === null);
    // FIX END

    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100%'}}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <span style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{nodes[currentNodeId]?.name || 'Node Map'}</span>
          </div>
          <div className="main-content">
            {rootNodes.map(node => renderNode(node.id))}
          </div>
        </div>
    );
};


const SettingsComponent = () => {
    const [settings, setSettings] = useState({ temp: 0.5, weight: 0.7, algo: 'MONX' });
    const handleSettingChange = (key, value) => {
        setSettings(s => ({ ...s, [key]: value }));
    };

    return (
        <div>
            <h2 style={{marginTop: 0}}>Settings</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                    <label>TEMPERATURE: {settings.temp}</label>
                    <input type="range" min="0" max="1" step="0.1" value={settings.temp} onChange={e => handleSettingChange('temp', e.target.value)} style={{ width: '100%' }} />
                </div>
                <div>
                    <label>WEIGHT: {settings.weight}</label>
                    <input type="range" min="0" max="1" step="0.1" value={settings.weight} onChange={e => handleSettingChange('weight', e.target.value)} style={{ width: '100%' }} />
                </div>
                <div>
                    <label>ALGORITHM</label>
                    <select value={settings.algo} onChange={e => handleSettingChange('algo', e.target.value)} style={{ width: '100%', padding: '8px', background: 'var(--button-bg)', color: 'var(--text-color)', border: '1px solid var(--border-color)' }}>
                        <option>MONX</option>
                        <option>GEMINI</option>
                    </select>
                </div>
            </div>
        </div>
    );
};


const DeleteModal = ({ node, onConfirm, onCancel }) => {
  if (!node) return null;
  return (
    <div style={modalOverlayStyle}>
      <div style={modalContentStyle}>
        <button onClick={onCancel} style={{ position: 'absolute', top: '10px', right: '10px', background: 'none', border: 'none', color: '#fff', fontSize: '1.5rem' }}>&times;</button>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '16px' }}>
          <div style={{ fontSize: '3rem', border: '3px solid #ccc', borderRadius: '50%', width: '60px', height: '60px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>!</div>
          <h2 style={{margin: 0}}>ATTENTION</h2>
        </div>
        <p>The node marked for deletion has been detected to contain one or more children.</p>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '24px' }}>
          <button onClick={onCancel} style={modalButtonStyle}>CANCEL</button>
          <button onClick={onConfirm} style={{...modalButtonStyle, background: 'var(--accent-color)'}}>DELETE</button>
        </div>
      </div>
    </div>
  );
};

const DetailsModal = ({ node, onCancel }) => {
  if (!node) return null;
  return (
    <div style={modalOverlayStyle}>
      <div style={modalContentStyle}>
        <button onClick={onCancel} style={{ position: 'absolute', top: '10px', right: '10px', background: 'none', border: 'none', color: '#fff', fontSize: '1.5rem' }}>&times;</button>
        <h3>{node.name} details</h3>
        <p><strong>NAME:</strong> {node.name}</p>
        <p><strong>DATE OF CREATION:</strong> {node.creationDate}</p>
        <p><strong>TEXT:</strong> {node.promptText}</p>
        <p><strong>REFERENCE FILES:</strong> {node.referenceFiles.length > 0 ? node.referenceFiles.map(f => typeof f === 'string' ? f : `node:${f.id}`).join(', ') : 'None'}</p>
        <p><strong>CHILD NODES:</strong> {node.childrenIds.length}</p>
      </div>
    </div>
  );
};

const modalOverlayStyle: React.CSSProperties = { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 };
const modalContentStyle: React.CSSProperties = { background: '#2a2a2a', padding: '24px', borderRadius: '8px', width: 'clamp(300px, 40%, 500px)', border: '1px solid var(--border-color)', position: 'relative' };
const modalButtonStyle: React.CSSProperties = { padding: '10px 20px', border: 'none', borderRadius: '4px', cursor: 'pointer', background: 'var(--button-bg)', color: 'var(--text-color)'};

// --- APP ---

const App = () => {
    const [nodes, setNodes] = useState<Nodes>({});
    const [currentNodeId, setCurrentNodeId] = useState<string | null>(null);
    const [activeView, setActiveView] = useState<View>('PROMPT');
    const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
    
    const [nodeToDelete, setNodeToDelete] = useState<string | null>(null);
    const [nodeToViewDetails, setNodeToViewDetails] = useState<string | null>(null);

    const handleGenerate = useCallback((promptText: string, files: AttachedFile[], holdFiles: boolean) => {
        const newId = `node-${Date.now()}`;
        const parentId = currentNodeId;
        
        setNodes(prevNodes => {
            const newNodes = { ...prevNodes };
            const newNode: Node = {
                id: newId,
                name: getNextNodeName(newNodes, parentId),
                parentId,
                childrenIds: [],
                isLocked: false,
                creationDate: new Date().toISOString().split('T')[0],
                promptText,
                referenceFiles: files.map(f => f.type === 'node' ? { type: 'node', id: f.id } : f.name),
                imageUrl: createDummyImageUrl(),
            };
            newNodes[newId] = newNode;

            if (parentId) {
                const parentNode = { ...newNodes[parentId] };
                parentNode.childrenIds = [...parentNode.childrenIds, newId];
                // If it's the first child, lock the parent (transition from iterative-blank to sequential)
                if (parentNode.childrenIds.length === 1) {
                    parentNode.isLocked = true;
                }
                newNodes[parentId] = parentNode;
            }
            return newNodes;
        });

        setCurrentNodeId(newId);
        if (Object.keys(nodes).length === 0) {
            setActiveView('VIEW');
        }

    }, [currentNodeId, nodes]);

    const handleNodeSelect = (nodeId: string) => {
        setCurrentNodeId(nodeId);
    };
    
    const handleLockToggle = (nodeId: string) => {
      setNodes(prev => {
        const newNodes = {...prev};
        const node = {...newNodes[nodeId]};
        
        // Logic from spec:
        // A node can revert to sequential(become locked again) if no further nodes were built in iterative context (ie. has 1 child)
        if (!node.isLocked && node.childrenIds.length <= 1) {
          node.isLocked = true;
        } else {
          // Unlocking puts it in a blank iterative context
          node.isLocked = false;
        }

        newNodes[nodeId] = node;
        return newNodes;
      });
    };
    
    const handleDeleteConfirm = () => {
      if (!nodeToDelete) return;
      
      setNodes(prev => {
        const toDeleteQueue = [nodeToDelete];
        const allToDeleteIds = new Set<string>();
        
        while(toDeleteQueue.length > 0) {
          const currentId = toDeleteQueue.shift();
          if (currentId) {
            allToDeleteIds.add(currentId);
            const node = prev[currentId];
            if (node) {
              node.childrenIds.forEach(childId => toDeleteQueue.push(childId));
            }
          }
        }

        const newNodes = { ...prev };
        let parentOfDeleted = null;
        
        allToDeleteIds.forEach(id => {
          if (id === nodeToDelete) parentOfDeleted = newNodes[id].parentId;
          delete newNodes[id];
        });

        // Clean up childrenIds from parents
        Object.keys(newNodes).forEach(key => {
          const node = { ...newNodes[key] };
          node.childrenIds = node.childrenIds.filter(childId => !allToDeleteIds.has(childId));
          newNodes[key] = node;
        });
        
        if (currentNodeId && allToDeleteIds.has(currentNodeId)) {
          setCurrentNodeId(parentOfDeleted);
        }
        
        return newNodes;
      });
      setNodeToDelete(null);
    };

    const currentNode = currentNodeId ? nodes[currentNodeId] : null;

    const renderMainContent = () => {
        if (!currentNode && activeView !== 'SETTINGS' && activeView !== 'PROMPT') {
            return <div className="empty-state">Nothing to display...</div>;
        }
        switch (activeView) {
            case 'VIEW':
                return <ViewComponent nodes={nodes} currentNodeId={currentNodeId} onNodeSelect={handleNodeSelect} onLockToggle={handleLockToggle} onDelete={setNodeToDelete} onDetails={setNodeToViewDetails} />;
            case 'NODE_MAP':
                return <NodeMapComponent nodes={nodes} currentNodeId={currentNodeId} onNodeSelect={handleNodeSelect} />;
            case 'CHAT':
                return <ChatComponent currentNode={currentNode} nodes={nodes} />;
            case 'SETTINGS':
                return <SettingsComponent />;
            case 'PROMPT':
                 return <div className="empty-state" style={{flexDirection: 'column', gap: '20px'}}>
                   <div style={{width: '80%', height: '60%', backgroundColor: '#111', borderRadius: '8px'}}></div>
                   <div>Start by typing a prompt below.</div>
                </div>;
            default:
                return null;
        }
    };

    return (
        <>
            <GlobalStyles />
            <div className="app-container">
                <div className="sidebar">
                    {['VIEW', 'NODE_MAP', 'CHAT', 'SETTINGS'].map((view) => (
                        <button
                            key={view}
                            onClick={() => setActiveView(view as View)}
                            className={`sidebar-button ${activeView === view ? 'active' : ''}`}
                        >
                            {view}
                        </button>
                    ))}
                </div>
                <div className="main-panel">
                    <div className="main-content">
                        {renderMainContent()}
                    </div>
                    {activeView !== 'SETTINGS' && (
                      <PromptComponent
                          currentNode={currentNode}
                          onGenerate={handleGenerate}
                          attachedFiles={attachedFiles}
                          setAttachedFiles={setAttachedFiles}
                      />
                    )}
                </div>
            </div>
            {nodeToDelete && <DeleteModal node={nodes[nodeToDelete]} onConfirm={handleDeleteConfirm} onCancel={() => setNodeToDelete(null)} />}
            {nodeToViewDetails && <DetailsModal node={nodes[nodeToViewDetails]} onCancel={() => setNodeToViewDetails(null)} />}
        </>
    );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);