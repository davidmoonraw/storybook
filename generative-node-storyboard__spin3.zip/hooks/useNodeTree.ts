import { useState, useCallback, useRef } from 'react';
import type { Node, Nodes, NodeReference, FileReference } from '../types';

const initialNodes: Nodes = {};

export const useNodeTree = () => {
    const [nodes, setNodes] = useState<Nodes>(initialNodes);
    const [currentNodeId, setCurrentNodeId] = useState<string | null>(null);
    const nodeIdCounter = useRef(0);

    const currentNode = currentNodeId ? nodes[currentNodeId] : null;

    const generateNodeId = useCallback(() => {
        const newId = `${String.fromCharCode(65 + nodeIdCounter.current)}1`;
        nodeIdCounter.current += 1;
        return newId;
    }, []);

    const getNode = useCallback((nodeId: string): Node | undefined => {
        return nodes[nodeId];
    }, [nodes]);

    const getRootNode = useCallback((): Node | null => {
         // FIX: Explicitly type `allNodes` as `Node[]` to resolve errors with `Object.values`.
         const allNodes: Node[] = Object.values(nodes);
         if (allNodes.length === 0) return null;
         return allNodes.find(n => n.parentId === null) || allNodes[0];
    }, [nodes]);

    const addNode = useCallback((prompt: string, parentId: string | null, referenceFiles: (Node | File)[]) => {
        setNodes(prevNodes => {
            const parentNode = parentId ? prevNodes[parentId] : null;
            const newId = generateNodeId();

            const newNode: Node = {
                id: newId,
                prompt,
                imageUrl: `https://picsum.photos/seed/${newId}/400/600`,
                parentId,
                childrenIds: [],
                referenceFiles: referenceFiles.map(f => {
                    if ('id' in f) {
                        return { type: 'node', nodeId: f.id } as NodeReference;
                    }
                    return { type: 'file', name: f.name, file: f } as FileReference;
                }),
                createdAt: Date.now(),
                isLocked: false, // New nodes are always unlocked
            };

            const newNodes = { ...prevNodes, [newId]: newNode };

            if (parentId && parentNode) {
                newNodes[parentId] = {
                    ...parentNode,
                    childrenIds: [...parentNode.childrenIds, newId],
                };
            }
            
            setCurrentNodeId(newId);
            return newNodes;
        });
    }, [generateNodeId]);

    const deleteNode = useCallback((nodeId: string) => {
        setNodes(prevNodes => {
            const newNodes = { ...prevNodes };
            const nodeToDelete = newNodes[nodeId];
            if (!nodeToDelete) return prevNodes;

            const nodesToRemove = new Set<string>([nodeId]);
            const queue = [...nodeToDelete.childrenIds];
            
            while (queue.length > 0) {
                const currentId = queue.shift();
                if (currentId && newNodes[currentId]) {
                    nodesToRemove.add(currentId);
                    queue.push(...newNodes[currentId].childrenIds);
                }
            }

            nodesToRemove.forEach(id => delete newNodes[id]);
            
            // Update parent's childrenIds
            if (nodeToDelete.parentId && newNodes[nodeToDelete.parentId]) {
                const parent = newNodes[nodeToDelete.parentId];
                parent.childrenIds = parent.childrenIds.filter(id => id !== nodeId);
            }

            // Update current node
            if (currentNodeId && nodesToRemove.has(currentNodeId)) {
                setCurrentNodeId(nodeToDelete.parentId);
            }

            return newNodes;
        });
    }, [currentNodeId]);
    
    const updateNode = useCallback((nodeId: string, updates: Partial<Node>) => {
        setNodes(prevNodes => {
            if (!prevNodes[nodeId]) return prevNodes;
            return {
                ...prevNodes,
                [nodeId]: { ...prevNodes[nodeId], ...updates }
            };
        });
    }, []);
    
    const getLineage = useCallback((nodeId: string): Node[] => {
        const lineage: Node[] = [];
        let current = nodes[nodeId];
        while (current) {
            lineage.unshift(current);
            current = current.parentId ? nodes[current.parentId] : null;
        }
        return lineage;
    }, [nodes]);

    const getNavigationMap = useCallback((nodeId: string | null) => {
        if (!nodeId || !nodes[nodeId]) return { up: null, down: null, left: null, right: null };
        const node = nodes[nodeId];
        
        const up = node.parentId;
        const down = node.childrenIds.length > 0 ? node.childrenIds[0] : null;

        let left = null;
        let right = null;

        if (node.parentId && nodes[node.parentId]) {
            const parent = nodes[node.parentId];
            const siblingIds = parent.childrenIds;
            const currentIndex = siblingIds.indexOf(nodeId);
            if (currentIndex > 0) {
                left = siblingIds[currentIndex - 1];
            }
            if (currentIndex < siblingIds.length - 1) {
                right = siblingIds[currentIndex + 1];
            }
        }
        
        return { up, down, left, right };

    }, [nodes]);

    return {
        nodes,
        currentNode,
        setCurrentNodeId,
        addNode,
        deleteNode,
        updateNode,
        getNode,
        getLineage,
        getRootNode,
        getNavigationMap,
    };
};