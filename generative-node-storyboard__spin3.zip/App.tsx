import React, { useState, useCallback, useMemo } from 'react';
import { HistoryPanel } from './components/HistoryPanel';
import { NodeMapPanel } from './components/NodeMapPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { ViewPanel } from './components/ViewPanel';
import { PromptBar } from './components/PromptBar';
import { Modal } from './components/Modal';
import { AddNodeModal } from './components/AddNodeModal';
import { useNodeTree } from './hooks/useNodeTree';
import type { Node, ViewMode, AppMode } from './types';

const App: React.FC = () => {
    const {
        nodes,
        currentNode,
        setCurrentNodeId,
        addNode,
        deleteNode,
        updateNode,
        getNode,
        getLineage,
        getRootNode,
        getNavigationMap,
    } = useNodeTree();

    const [viewMode, setViewMode] = useState<ViewMode>('iterative');
    const [isFullView, setIsFullView] = useState(false);
    const [historyViewToggled, setHistoryViewToggled] = useState(false);
    const [showNodeReferences, setShowNodeReferences] = useState(false);
    
    const [modal, setModal] = useState<'delete' | 'details' | 'add' | 'enlarge' | null>(null);
    const [modalNode, setModalNode] = useState<Node | null>(null);
    const [referenceFilesToAdd, setReferenceFilesToAdd] = useState<(Node | File)[]>([]);


    const handleNodeSelect = useCallback((nodeId: string) => {
        setCurrentNodeId(nodeId);
    }, [setCurrentNodeId]);

    const handleAddNode = useCallback((prompt: string, parentId: string | null, referenceFiles: (Node | File)[]) => {
        addNode(prompt, parentId, referenceFiles);
        setReferenceFilesToAdd([]);
    }, [addNode]);

    const handleDeleteRequest = useCallback((node: Node) => {
        setModalNode(node);
        setModal('delete');
    }, []);

    const handleDeleteConfirm = useCallback(() => {
        if (modalNode) {
            deleteNode(modalNode.id);
        }
        setModal(null);
        setModalNode(null);
    }, [modalNode, deleteNode]);

    const appMode: AppMode = useMemo(() => {
        if (!currentNode) return 'iterative';
        return currentNode.isLocked ? 'sequential' : 'iterative';
    }, [currentNode]);
    
    const handleToggleLock = useCallback((nodeId: string) => {
        const node = getNode(nodeId);
        if (node) {
            if (!node.isLocked) { // Can only lock if it's in a "blank iterative context" or has 1 child for sequential flow
                 if (node.childrenIds.length <= 1) {
                    updateNode(nodeId, { isLocked: true });
                 }
            } else { // Can always unlock
                updateNode(nodeId, { isLocked: false });
            }
        }
    }, [getNode, updateNode]);

    const openDetailsModal = useCallback((node: Node) => {
        setModalNode(node);
        setModal('details');
    }, []);

    const openEnlargeModal = useCallback((node: Node) => {
        setModalNode(node);
        setModal('enlarge');
    }, []);

    const handleNavigate = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
        const navMap = getNavigationMap(currentNode?.id ?? null);
        const nextNodeId = navMap[direction];
        if (nextNodeId) {
            setCurrentNodeId(nextNodeId);
        }
    }, [currentNode, getNavigationMap, setCurrentNodeId]);

    const handleAddNodesAsRefs = (nodesToAdd: Node[]) => {
        setReferenceFilesToAdd(prev => [...prev, ...nodesToAdd]);
        setModal(null);
    }


    return (
        <div className="bg-black text-gray-300 font-sans h-screen flex flex-col p-4 gap-4">
            <div className="flex-grow flex gap-4 overflow-hidden">
                {/* Left Panel */}
                <div className="w-1/4 flex flex-col gap-4">
                    <HistoryPanel
                        currentNode={currentNode}
                        getLineage={getLineage}
                        getNode={getNode}
                        viewToggled={historyViewToggled}
                        onToggleView={() => setHistoryViewToggled(!historyViewToggled)}
                    />
                    <NodeMapPanel
                        nodes={Object.values(nodes)}
                        currentNode={currentNode}
                        onNodeSelect={handleNodeSelect}
                        appMode={appMode}
                        rootNode={getRootNode()}
                    />
                </div>

                {/* Center Panel */}
                <div className="w-1/2 flex flex-col">
                    <ViewPanel
                        nodes={nodes}
                        currentNode={currentNode}
                        appMode={appMode}
                        isFullView={isFullView}
                        setIsFullView={setIsFullView}
                        onToggleLock={handleToggleLock}
                        onNodeSelect={handleNodeSelect}
                        onDeleteRequest={handleDeleteRequest}
                        onDetailsRequest={openDetailsModal}
                        onEnlargeRequest={openEnlargeModal}
                        onNavigate={handleNavigate}
                        showNodeReferences={showNodeReferences}
                        setShowNodeReferences={setShowNodeReferences}
                    />
                </div>

                {/* Right Panel */}
                <div className={`w-1/4 flex flex-col ${isFullView ? 'hidden' : ''}`}>
                    <SettingsPanel />
                </div>
            </div>

            {/* Bottom Panel */}
            <div className="flex-shrink-0">
                <PromptBar
                    onSubmit={(prompt, files) => handleAddNode(prompt, currentNode ? currentNode.id : null, files)}
                    onAddNodeClick={() => setModal('add')}
                    referenceFilesToAdd={referenceFilesToAdd}
                />
            </div>
            
            {/* Modals */}
            {modal === 'delete' && modalNode && (
                 <Modal onClose={() => setModal(null)} title="ATTENTION">
                    <div className="text-center">
                        <p className="my-4">
                            {modalNode.childrenIds.length > 0
                                ? `The node ${modalNode.id} marked for deletion has been detected to contain one or more childs to be removed.`
                                : `The node ${modalNode.id} marked for deletion was not detected with childs.`
                            }
                        </p>
                        <div className="flex justify-center gap-4 mt-6">
                            <button onClick={handleDeleteConfirm} className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded">DELETE</button>
                            <button onClick={() => setModal(null)} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded">CANCEL</button>
                        </div>
                    </div>
                </Modal>
            )}
             {modal === 'enlarge' && modalNode && (
                <div onClick={() => setModal(null)} className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-8 cursor-pointer">
                   <img src={modalNode.imageUrl} alt={modalNode.id} className="max-w-full max-h-full object-contain" onClick={(e) => e.stopPropagation()} />
                </div>
            )}
            {modal === 'details' && modalNode && (
                <Modal onClose={() => setModal(null)} title={`${modalNode.id} details`}>
                    <div className="space-y-2 text-sm">
                        <p><strong>Node Name:</strong> {modalNode.id}</p>
                        <p><strong>Date of Creation:</strong> {new Date(modalNode.createdAt).toLocaleString()}</p>
                        <p><strong>Creation Prompt:</strong> "{modalNode.prompt}"</p>
                        <p><strong>Reference Files:</strong> {modalNode.referenceFiles.length > 0 ? modalNode.referenceFiles.map(f => f.type === 'file' ? f.name : f.nodeId).join(', ') : 'None'}</p>
                        <p><strong>Child Nodes:</strong> {modalNode.childrenIds.length}</p>
                    </div>
                     <div className="flex justify-center mt-6">
                         <button onClick={() => navigator.clipboard.writeText(JSON.stringify(modalNode, null, 2))} className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-6 rounded">Copy Details</button>
                    </div>
                </Modal>
            )}
            {modal === 'add' && (
                <AddNodeModal
                    nodes={Object.values(nodes)}
                    onClose={() => setModal(null)}
                    onAdd={handleAddNodesAsRefs}
                />
            )}
        </div>
    );
};

export default App;
