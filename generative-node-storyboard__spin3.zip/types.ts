
export interface Node {
    id: string;
    prompt: string;
    imageUrl: string;
    parentId: string | null;
    childrenIds: string[];
    referenceFiles: (NodeReference | FileReference)[];
    createdAt: number;
    isLocked: boolean;
}

export interface NodeReference {
    type: 'node';
    nodeId: string;
}

export interface FileReference {
    type: 'file';
    name: string;
    file: File;
}

export type Nodes = Record<string, Node>;

export type ViewMode = 'iterative' | 'sequential' | 'single' | 'full';

export type AppMode = 'iterative' | 'sequential';
