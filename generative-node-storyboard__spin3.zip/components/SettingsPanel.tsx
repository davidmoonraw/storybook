
import React, { useState } from 'react';

const SettingInput: React.FC<{ label: string; value: string | number; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; type?: string; }> = ({ label, value, onChange, type = "text" }) => (
    <div className="mb-4">
        <label className="block text-xs text-gray-400 mb-1">{label}</label>
        <input
            type={type}
            value={value}
            onChange={onChange}
            className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-sm outline-none focus:border-gray-500"
        />
    </div>
);

const SettingSelect: React.FC<{ label: string; value: string; onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; options: string[]; }> = ({ label, value, onChange, options }) => (
     <div className="mb-4">
        <label className="block text-xs text-gray-400 mb-1">{label}</label>
        <select
            value={value}
            onChange={onChange}
            className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-sm outline-none focus:border-gray-500 appearance-none"
        >
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    </div>
);


export const SettingsPanel: React.FC = () => {
    const [temperature, setTemperature] = useState(0.5);
    const [weight, setWeight] = useState(0.7);
    const [algorithm, setAlgorithm] = useState('MONX');

    return (
        <div className="bg-[#1a1a1a] p-3 rounded-lg flex-grow">
            <h3 className="text-sm font-bold tracking-widest underline underline-offset-4 mb-6">SETTINGS</h3>
            
            <SettingInput
                label="TEMPERATURE"
                type="number"
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
            />
             <SettingInput
                label="WEIGHT"
                type="number"
                value={weight}
                onChange={(e) => setWeight(parseFloat(e.target.value))}
            />
            <SettingSelect
                label="ALGORITHM"
                value={algorithm}
                onChange={(e) => setAlgorithm(e.target.value)}
                options={['MONX', 'DALL-E', 'Midjourney']}
            />
        </div>
    );
};
