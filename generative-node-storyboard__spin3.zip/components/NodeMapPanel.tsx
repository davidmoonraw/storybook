
import React, { useState } from 'react';
import type { Node, AppMode } from '../types';
import { PlusIcon } from './Icons';

interface NodeMapPanelProps {
    nodes: Node[];
    currentNode: Node | null;
    rootNode: Node | null;
    onNodeSelect: (nodeId: string) => void;
    appMode: AppMode;
}

const NodeCircle: React.FC<{ node: Node; color: string; onNodeSelect: (id: string) => void; }> = ({ node, color, onNodeSelect }) => {
    const [tooltip, setTooltip] = useState(false);
    return (
        <div className="relative">
            <div
                className={`w-4 h-4 rounded-full cursor-pointer ${color}`}
                onClick={() => onNodeSelect(node.id)}
                onMouseEnter={() => setTooltip(true)}
                onMouseLeave={() => setTooltip(false)}
            />
            {tooltip && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-white text-xs rounded">
                    {node.id}
                </div>
            )}
        </div>
    );
};


export const NodeMapPanel: React.FC<NodeMapPanelProps> = ({ nodes, currentNode, rootNode, onNodeSelect, appMode }) => {
    const nodeCount = nodes.length;

    const renderTree = (nodeId: string, level = 0): JSX.Element | null => {
        const node = nodes.find(n => n.id === nodeId);
        if (!node) return null;

        let color = 'bg-gray-500'; // default
        if (currentNode) {
            if (node.id === currentNode.id) {
                color = appMode === 'iterative' ? 'bg-red-500' : 'bg-yellow-500';
            } else if (node.id === rootNode?.id) {
                color = 'bg-blue-500';
            }
        }

        return (
            <div key={node.id} className="flex items-start">
                <div className={`pl-${level * 4}`}>
                    <div className="flex items-center">
                       {level > 0 && <div className="w-4 h-px bg-gray-600 mr-2"></div>}
                       <NodeCircle node={node} color={color} onNodeSelect={onNodeSelect} />
                    </div>
                    {node.childrenIds.length > 0 && (
                        <div className="flex">
                            <div className="w-4 flex justify-center">
                                <div className="h-full w-px bg-gray-600"></div>
                            </div>
                            <div className="flex flex-col">
                                {node.childrenIds.map(childId => renderTree(childId, level + 1))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    };

    return (
        <div className="bg-[#1a1a1a] p-3 rounded-lg flex flex-col flex-grow">
            <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-bold tracking-widest underline underline-offset-4">NODE MAP</h3>
                {nodeCount > 0 && (
                     <div className="bg-gray-700 text-xs px-2 py-1 rounded-full">{nodeCount} {nodeCount === 1 ? 'node' : 'nodes'}</div>
                )}
            </div>
            <div className="flex-grow overflow-auto p-2">
                {rootNode ? (
                    renderTree(rootNode.id)
                ) : (
                    <div className="text-center text-gray-500">NOTHING TO DISPLAY....</div>
                )}
            </div>
        </div>
    );
};