import React, { useState } from 'react';
import type { Node } from '../types';
import { XIcon } from './Icons';

interface AddNodeModalProps {
    nodes: Node[];
    onClose: () => void;
    onAdd: (selectedNodes: Node[]) => void;
}

const NodeSelectionCard: React.FC<{ node: Node; isSelected: boolean; onSelect: () => void; }> = ({ node, isSelected, onSelect }) => (
    <div className={`relative cursor-pointer group rounded-lg overflow-hidden border-2 ${isSelected ? 'border-blue-500' : 'border-transparent'}`} onClick={onSelect}>
        <img src={node.imageUrl} alt={node.id} className="w-full h-48 object-cover transition-transform group-hover:scale-105" />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-end p-2">
            <span className="text-white font-bold">{node.id}</span>
        </div>
        {isSelected && (
            <div className="absolute top-2 right-2 bg-blue-500 text-white rounded-full h-6 w-6 flex items-center justify-center">
                ✓
            </div>
        )}
    </div>
);

export const AddNodeModal: React.FC<AddNodeModalProps> = ({ nodes, onClose, onAdd }) => {
    const [selectedNodeIds, setSelectedNodeIds] = useState<Set<string>>(new Set());
    const [searchTerm, setSearchTerm] = useState('');

    const handleSelect = (nodeId: string) => {
        setSelectedNodeIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(nodeId)) {
                newSet.delete(nodeId);
            } else {
                newSet.add(nodeId);
            }
            return newSet;
        });
    };

    const handleAddClick = () => {
        const selectedNodes = nodes.filter(node => selectedNodeIds.has(node.id));
        onAdd(selectedNodes);
    };
    
    const filteredNodes = nodes.filter(node => 
        node.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
        node.prompt.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-[#2a2a2a] border border-gray-700 rounded-lg w-full max-w-4xl h-[80vh] flex flex-col p-4" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4 flex-shrink-0">
                    <input
                        type="text"
                        placeholder="Search..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-1/2 bg-gray-800 border border-gray-700 rounded p-2 text-sm outline-none focus:border-gray-500"
                    />
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon /></button>
                </div>

                <div className="flex-grow overflow-y-auto pr-2">
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {filteredNodes.map(node => (
                            <NodeSelectionCard 
                                key={node.id}
                                node={node}
                                isSelected={selectedNodeIds.has(node.id)}
                                onSelect={() => handleSelect(node.id)}
                            />
                        ))}
                    </div>
                </div>

                <div className="flex justify-end pt-4 mt-auto flex-shrink-0 border-t border-gray-700">
                    <button
                        onClick={handleAddClick}
                        disabled={selectedNodeIds.size === 0}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded disabled:bg-gray-500 disabled:cursor-not-allowed"
                    >
                        Add ({selectedNodeIds.size})
                    </button>
                </div>
            </div>
        </div>
    );
};
