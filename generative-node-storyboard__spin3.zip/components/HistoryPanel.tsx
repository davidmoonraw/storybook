import React from 'react';
import type { Node } from '../types';
import { EyeIcon, EyeOffIcon } from './Icons';

interface HistoryPanelProps {
    currentNode: Node | null;
    getLineage: (nodeId: string) => Node[];
    getNode: (nodeId: string) => Node | undefined;
    viewToggled: boolean;
    onToggleView: () => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({ currentNode, getLineage, getNode, viewToggled, onToggleView }) => {
    const lineage = currentNode ? getLineage(currentNode.id) : [];

    return (
        <div className="bg-[#1a1a1a] p-3 rounded-lg flex flex-col flex-grow">
            <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-bold tracking-widest underline underline-offset-4">HISTORY</h3>
                <button onClick={onToggleView} className="text-gray-400 hover:text-white">
                    {viewToggled ? <EyeIcon /> : <EyeOffIcon />}
                </button>
            </div>
            <p className="text-sm text-gray-400 mb-4">{currentNode ? currentNode.id : ''}</p>
            <div className="flex-grow overflow-y-auto pr-2 relative">
                {lineage.length > 0 ? (
                    <ul className="space-y-2 text-sm">
                        {lineage.map((node, index) => {
                             const parent = node.parentId ? getNode(node.parentId) : null;
                             // Root node is iterative by default, or any unlocked node is iterative
                             const isIterativeCreation = parent ? !parent.isLocked : true;

                            return (
                                <li key={node.id} className="flex items-start justify-between">
                                    <div className="flex-1 min-w-0">
                                        <span className="break-words">
                                            {viewToggled && isIterativeCreation && index > 0 && <span className="mr-2">+</span>}
                                            {node.prompt}
                                        </span>
                                    </div>
                                    {viewToggled && index > 0 && (
                                       <span className="text-gray-500 ml-4 flex-shrink-0">{node.id}</span>
                                    )}
                                </li>
                            )
                        })}
                    </ul>
                ) : (
                    <div className="text-center text-gray-500">NOTHING TO DISPLAY....</div>
                )}
                 {/* Mock scrollbar */}
                <div className="absolute right-0 top-0 h-full w-1.5 bg-black rounded-full">
                    <div className="bg-gray-700 w-full h-1/4 rounded-full"></div>
                </div>
            </div>
        </div>
    );
};
