
import React from 'react';
import type { Node } from '../types';
import { LockIcon, LockOpenIcon, ShareIcon, InfoIcon, TrashIcon } from './Icons';

interface CardProps {
    node: Node;
    onHeaderClick?: (nodeId: string) => void;
    onDelete: (node: Node) => void;
    onDetails: (node: Node) => void;
    onEnlarge: (node: Node) => void;
    onToggleLock: (nodeId: string) => void;
    isCurrent: boolean;
    isParent?: boolean;
}

export const Card: React.FC<CardProps> = ({ node, onHeaderClick, onDelete, onDetails, onEnlarge, onToggleLock, isCurrent, isParent = false }) => {
    return (
        <div className="flex flex-col items-center gap-2">
            <h2 
                className={`text-2xl font-mono cursor-pointer ${isCurrent ? 'text-white' : 'text-gray-500'}`}
                onClick={() => onHeaderClick && onHeaderClick(node.id)}
            >
                {node.id}
            </h2>
            <div className={`p-2 rounded-lg bg-[#1a1a1a] border ${isCurrent || isParent ? 'border-gray-500' : 'border-transparent'}`}>
                <img
                    src={node.imageUrl}
                    alt={node.id}
                    className="w-40 h-64 object-cover rounded-md cursor-pointer"
                    onClick={() => onEnlarge(node)}
                />
                <div className="flex justify-between items-center mt-2 px-1">
                    <div className="flex gap-2 text-gray-400">
                        <button onClick={() => onToggleLock(node.id)} className="hover:text-white">
                            {node.isLocked ? <LockIcon /> : <LockOpenIcon />}
                        </button>
                        <button className="hover:text-white"><ShareIcon /></button>
                        <button onClick={() => onDetails(node)} className="hover:text-white"><InfoIcon /></button>
                    </div>
                    <button onClick={() => onDelete(node)} className="text-gray-400 hover:text-red-500">
                        <TrashIcon />
                    </button>
                </div>
            </div>
        </div>
    );
};
