import React, { useState, useRef, useEffect } from 'react';
import type { Node } from '../types';
import { PlusIcon, SendIcon, XIcon } from './Icons';

interface PromptBarProps {
    onSubmit: (prompt: string, referenceFiles: (Node | File)[]) => void;
    onAddNodeClick: () => void;
    referenceFilesToAdd: (Node | File)[];
}

export const PromptBar: React.FC<PromptBarProps> = ({ onSubmit, onAddNodeClick, referenceFilesToAdd }) => {
    const [input, setInput] = useState('');
    const [files, setFiles] = useState<(Node | File)[]>([]);
    const [isHold, setIsHold] = useState(false);
    const [showAddMenu, setShowAddMenu] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (referenceFilesToAdd.length > 0) {
            setFiles(prev => [...prev, ...referenceFilesToAdd]);
        }
    }, [referenceFilesToAdd]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (input.trim() === '' && files.length === 0) return;
        onSubmit(input, files);
        setInput('');
        if (!isHold) {
            setFiles([]);
        }
    };
    
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            const newFiles = Array.from(event.target.files);
            setFiles(prev => [...prev, ...newFiles]);
        }
        // Reset file input to allow selecting the same file again
        if(fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };
    
    const removeFile = (index: number) => {
        setFiles(files.filter((_, i) => i !== index));
    };

    return (
        <div className="relative">
            {showAddMenu && (
                 <div className="absolute bottom-full left-4 mb-2 bg-[#2a2a2a] p-2 rounded-lg shadow-lg border border-gray-700">
                     <button onClick={() => { onAddNodeClick(); setShowAddMenu(false); }} className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 rounded">Add node</button>
                     <button onClick={() => { fileInputRef.current?.click(); setShowAddMenu(false); }} className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 rounded">Upload file</button>
                 </div>
            )}
            <div className="bg-[#2a2a2a] p-2 rounded-lg flex items-end gap-2">
                <div className="flex flex-col gap-2">
                   {files.length > 0 && <button onClick={() => setIsHold(!isHold)} className={`w-10 h-10 flex items-center justify-center rounded-full text-sm font-mono ${isHold ? 'bg-blue-600 text-white' : 'bg-gray-700'}`}>||</button>}
                   <button onClick={() => setShowAddMenu(!showAddMenu)} className="bg-gray-700 w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-600"><PlusIcon /></button>
                </div>
                <form onSubmit={handleSubmit} className="flex-grow bg-gray-800 rounded-lg">
                    <div className="p-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Type..."
                            className="w-full bg-transparent outline-none text-white"
                        />
                    </div>
                    {files.length > 0 && (
                        <>
                            <hr className="border-gray-600" />
                            <div className="p-2 flex flex-wrap gap-2">
                                {files.map((file, index) => (
                                    <div key={index} className="bg-gray-700 rounded-full px-3 py-1 text-sm flex items-center gap-2">
                                        <span>{'name' in file ? file.name : `Node ${file.id}`}</span>
                                        <button onClick={() => removeFile(index)} className="hover:text-red-500"><XIcon /></button>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                </form>
                <button type="submit" onClick={handleSubmit} className="bg-gray-700 w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-600"><SendIcon /></button>
                 <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" multiple />
            </div>
        </div>
    );
};
