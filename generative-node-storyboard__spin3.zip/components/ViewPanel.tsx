import React from 'react';
import { Card } from './Card';
import type { Node, Nodes, AppMode } from '../types';
import { EyeIcon, BookOpenIcon, ArrowsExpandIcon, SwitchHorizontalIcon, ArrowUpIcon, ArrowDownIcon, ArrowLeftIcon, ArrowRightIcon } from './Icons';

interface ViewPanelProps {
    nodes: Nodes;
    currentNode: Node | null;
    appMode: AppMode;
    isFullView: boolean;
    setIsFullView: (isFull: boolean) => void;
    onToggleLock: (nodeId: string) => void;
    onNodeSelect: (nodeId: string) => void;
    onDeleteRequest: (node: Node) => void;
    onDetailsRequest: (node: Node) => void;
    onEnlargeRequest: (node: Node) => void;
    onNavigate: (direction: 'up' | 'down' | 'left' | 'right') => void;
    showNodeReferences: boolean;
    setShowNodeReferences: (show: boolean) => void;
}

const SlideArrows: React.FC<{ appMode: AppMode; onNavigate: (dir: 'up' | 'down' | 'left' | 'right') => void }> = ({ appMode, onNavigate }) => (
    <div className="grid grid-cols-3 gap-1 w-24 absolute right-8 top-1/2 -translate-y-1/2">
        <div />
        <button onClick={() => onNavigate('up')} className={`p-2 rounded-full bg-gray-800 hover:bg-gray-700 ${appMode === 'sequential' ? 'opacity-30 cursor-not-allowed' : ''}`} disabled={appMode==='sequential'}><ArrowUpIcon /></button>
        <div />
        <button onClick={() => onNavigate('left')} className="p-2 rounded-full bg-gray-800 hover:bg-gray-700"><ArrowLeftIcon /></button>
        <div />
        <button onClick={() => onNavigate('right')} className="p-2 rounded-full bg-gray-800 hover:bg-gray-700"><ArrowRightIcon /></button>
        <div />
        <button onClick={() => onNavigate('down')} className={`p-2 rounded-full bg-gray-800 hover:bg-gray-700 ${appMode === 'sequential' ? 'opacity-30 cursor-not-allowed' : ''}`} disabled={appMode==='sequential'}><ArrowDownIcon /></button>
        <div />
    </div>
);

const ReferenceNodeCard: React.FC<{node: Node}> = ({ node }) => (
    <div className="flex flex-col items-center gap-1">
        <img src={node.imageUrl} alt={node.id} className="w-24 h-36 object-cover rounded-md" />
        <span className="text-xs text-gray-400">{node.id}</span>
    </div>
);

const ReferenceFileCard: React.FC<{name: string}> = ({ name }) => (
    <div className="flex flex-col items-center gap-1 w-24 h-40 bg-gray-800 rounded-md justify-center p-2">
        <span className="text-xs text-gray-400 text-center break-all">{name}</span>
    </div>
);


export const ViewPanel: React.FC<ViewPanelProps> = (props) => {
    const { nodes, currentNode, appMode, isFullView, setIsFullView, onToggleLock, onNodeSelect, onDeleteRequest, onDetailsRequest, onEnlargeRequest, onNavigate, showNodeReferences, setShowNodeReferences } = props;

    const renderContent = () => {
        if (isFullView) {
            return (
                 <div className="flex flex-col h-full">
                    <input type="text" placeholder="Search..." className="w-full bg-gray-800 border border-gray-700 rounded p-2 mb-4 text-sm outline-none focus:border-gray-500" />
                    <div className="flex-grow overflow-y-auto pr-2">
                       <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {/* FIX: Explicitly type `node` as `Node` to fix TypeScript error where `node` is inferred as `unknown`. */}
                            {Object.values(nodes).map((node: Node) => (
                                <Card 
                                    key={node.id} 
                                    node={node} 
                                    onDelete={onDeleteRequest} 
                                    onDetails={onDetailsRequest} 
                                    onEnlarge={onEnlargeRequest} 
                                    onToggleLock={onToggleLock}
                                    onHeaderClick={onNodeSelect}
                                    isCurrent={currentNode?.id === node.id}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            );
        }

        if (!currentNode) {
            return <div className="text-center text-gray-500 text-2xl">NOTHING TO DISPLAY.....</div>;
        }
        
        const children = currentNode.childrenIds.map(id => nodes[id]).filter(Boolean);
        const parent = currentNode.parentId ? nodes[currentNode.parentId] : null;

        if (appMode === 'iterative') {
             return (
                <div className="flex items-center justify-center gap-8">
                   <Card 
                        node={currentNode} 
                        isCurrent={true} 
                        isParent={true}
                        onDelete={onDeleteRequest} 
                        onDetails={onDetailsRequest} 
                        onEnlarge={onEnlargeRequest} 
                        onToggleLock={onToggleLock}
                   />
                   {children.length > 0 && <div className="w-px h-64 bg-gray-700" />}
                   <div className="flex gap-4">
                    {children.map(child => (
                         <Card key={child.id} node={child} isCurrent={false} onDelete={onDeleteRequest} onDetails={onDetailsRequest} onEnlarge={onEnlargeRequest} onToggleLock={onToggleLock} onHeaderClick={onNodeSelect}/>
                    ))}
                   </div>
                </div>
            )
        }
        
        // Sequential Mode: show parent and current
        const displayNodes = parent ? [parent, currentNode] : [currentNode];
        return (
            <div className="flex items-center justify-center gap-4">
                {displayNodes.map(node => (
                    <Card 
                        key={node.id} 
                        node={node} 
                        isCurrent={node.id === currentNode.id}
                        onDelete={onDeleteRequest} 
                        onDetails={onDetailsRequest} 
                        onEnlarge={onEnlargeRequest} 
                        onToggleLock={onToggleLock}
                        onHeaderClick={onNodeSelect}
                    />
                ))}
            </div>
        )
    };

    return (
        <div className="bg-black p-3 rounded-lg flex-grow flex flex-col relative">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-sm font-bold tracking-widest underline underline-offset-4">VIEW</h3>
                <div className="flex items-center gap-4 text-gray-400">
                    <button onClick={() => setShowNodeReferences(!showNodeReferences)} className="hover:text-white"><EyeIcon /></button>
                    <button onClick={() => currentNode && onToggleLock(currentNode.id)} className="hover:text-white"><SwitchHorizontalIcon /></button>
                    <button onClick={() => setIsFullView(!isFullView)} className="hover:text-white">{isFullView ? <BookOpenIcon/> : <ArrowsExpandIcon />}</button>
                </div>
            </div>
            <div className="flex-grow flex items-center justify-center">
                {renderContent()}
            </div>
            {currentNode && !isFullView && <SlideArrows appMode={appMode} onNavigate={onNavigate} />}

            {showNodeReferences && currentNode && (
                <>
                <hr className="border-gray-700 my-4" />
                <div className="flex-shrink-0 h-48 overflow-y-auto">
                    <div className="flex flex-wrap gap-4 p-2">
                        {currentNode.referenceFiles.map((ref, index) => {
                            if (ref.type === 'node') {
                                const refNode = nodes[ref.nodeId];
                                return refNode ? <ReferenceNodeCard key={index} node={refNode} /> : null;
                            }
                            return <ReferenceFileCard key={index} name={ref.name} />;
                        })}
                    </div>
                </div>
                </>
            )}
        </div>
    );
};