
import React, { useState, useEffect, useMemo, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { configureStore, createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { Provider, useSelector, useDispatch } from 'react-redux';
import { GoogleGenAI, Modality } from "@google/genai";

// --- 1. ICONS ---
const EyeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.816 1.221-2.25 2.53-4.223 3.39A13.133 13.133 0 0 1 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.133 13.133 0 0 1 1.172 8z"/><path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/></svg>;
const EyeSlashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="m10.79 12.912-1.614-1.615a3.5 3.5 0 0 1-4.474-4.474l-2.06-2.06C.938 6.278 0 8 0 8s3 5.5 8 5.5a12.01 12.01 0 0 0 5.022-1.31L10.79 12.912zM14.328 9.94a13.133 13.133 0 0 1-1.66-2.043C11.879 6.832 10.119 5.5 8 5.5c-.716 0-1.4.133-2.017.382l-1.954-1.954A13.133 13.133 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.18-.195.278-.335.48-.83 1.12-1.465 1.755l-1.845-1.845zm-2.9-1.85-1.959-1.959a3.5 3.5 0 0 0-4.474-4.474L2.35 1.126 1.126 2.35 14.874 16l1.224-1.224-3.695-3.695z"/></svg>;
const PlusIcon = () => <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M7.75 2a.75.75 0 0 1 .75.75V7h4.25a.75.75 0 0 1 0 1.5H8.5v4.25a.75.75 0 0 1-1.5 0V8.5H2.75a.75.75 0 0 1 0-1.5H7V2.75A.75.75 0 0 1 7.75 2Z"></path></svg>;
const SendIcon = () => <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M1.5 8.164a.75.75 0 0 1 .744-.753l10.252-2.18L3.13 7.82a.75.75 0 0 1-.613-.726c-.03-1.32.748-2.544 2.13-2.93l11.25-3.214a.75.75 0 0 1 .966.966L13.62 13.13a.75.75 0 0 1-.726-.613l-1.591-9.366-7.804 8.293a.75.75 0 0 1-1.292-.743L3.63 8.35l-2.09-.273a.75.75 0 0 1-.04-.013Z"></path></svg>;
const IterativeIcon = () => <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path fillRule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8Zm13.5 0a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0ZM8 5a.5.5 0 0 1 .5.5v2h2a.5.5 0 0 1 0 1h-2v2a.5.5 0 0 1-1 0v-2h-2a.5.5 0 0 1 0-1h2v-2A.5.5 0 0 1 8 5Z"/></svg>;
const SequentialIcon = () => <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path fillRule="evenodd" d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8Zm13.5 0a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0ZM4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8Z"/></svg>;
const SearchIcon = () => <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg>;
const ArrowLeftIcon = () => <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path fillRule="evenodd" d="M12 8a.5.5 0 0 1-.5.5H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5a.5.5 0 0 1 .5.5z"/></svg>;
const ArrowRightIcon = () => <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path fillRule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z"/></svg>;
const LoadingSpinner = () => <div style={{width: 16, height: 16, border: '2px solid var(--color-border-primary)', borderTopColor: 'var(--color-accent)', borderRadius: '50%', animation: 'spin 1s linear infinite'}}></div>;

// --- 2. GEMINI API SETUP ---
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- 3. REDUX STATE AND STORE ---

// Interfaces
interface ReferenceFile {
    id: string;
    name: string;
    type: 'node' | 'upload';
    data: string; // nodeId or file content
}

interface Node {
    id: string;
    name: string;
    promptString: string;
    context: 'iterative' | 'sequential';
    image: string; // base64
    parentId: string | null;
    childrenIds: string[];
    creationDate: string;
    referenceFiles: ReferenceFile[];
}

interface NodesState {
    nodes: Record<string, Node>;
    rootNodeId: string | null;
    status: 'idle' | 'loading' | 'succeeded' | 'failed';
    error: string | null;
}

interface AppState {
    appContext: string | null; // The ID of the working node
    viewMode: 'iterative' | 'sequential';
    storyViewMode: boolean; // true for 'on', false for 'off'
    searchViewActive: boolean;
    showReferences: boolean;
}

const initialNodesState: NodesState = {
    nodes: {},
    rootNodeId: null,
    status: 'idle',
    error: null
};

const initialAppState: AppState = {
    appContext: null,
    viewMode: 'iterative',
    storyViewMode: false,
    searchViewActive: false,
    showReferences: false,
};

// Async Thunk for Image Generation
export const generateImage = createAsyncThunk(
    'nodes/generateImage',
    async (prompt: string, { getState, dispatch }) => {
        const state = getState() as { app: AppState, nodes: NodesState };
        const parentId = state.app.appContext;
        const viewMode = state.app.viewMode;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [{ text: prompt }] },
            config: { responseModalities: [Modality.IMAGE] },
        });

        const imagePart = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (!imagePart || !imagePart.inlineData) {
            throw new Error('Image generation failed or returned no image.');
        }

        const base64ImageBytes: string = imagePart.inlineData.data;
        const newNodeId = `node-${Date.now()}`;

        // Create a simple naming scheme for now
        const parentNode = parentId ? state.nodes.nodes[parentId] : null;
        let newNodeName = "A1";
        if (parentNode) {
            const letter = parentNode.name.charAt(0);
            const num = parentNode.childrenIds.length + 1;
            newNodeName = `${letter}${num}`;
        }
        
        const newNode: Node = {
            id: newNodeId,
            name: newNodeName,
            promptString: prompt,
            context: viewMode,
            image: `data:image/png;base64,${base64ImageBytes}`,
            parentId: parentId,
            childrenIds: [],
            creationDate: new Date().toISOString(),
            referenceFiles: [],
        };
        
        dispatch(addNode(newNode));
        return newNode;
    }
);


// Slices
const nodeSlice = createSlice({
    name: 'nodes',
    initialState: initialNodesState,
    reducers: {
        addNode: (state, action: PayloadAction<Node>) => {
            const node = action.payload;
            state.nodes[node.id] = node;
            if (node.parentId) {
                state.nodes[node.parentId]?.childrenIds.push(node.id);
            } else {
                state.rootNodeId = node.id;
            }
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(generateImage.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(generateImage.fulfilled, (state, action) => {
                state.status = 'succeeded';
            })
            .addCase(generateImage.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message || 'Something went wrong';
            });
    }
});

const appSlice = createSlice({
    name: 'app',
    initialState: initialAppState,
    reducers: {
        setAppContext: (state, action: PayloadAction<string | null>) => {
            state.appContext = action.payload;
        },
        toggleViewMode: (state) => {
            state.viewMode = state.viewMode === 'iterative' ? 'sequential' : 'iterative';
        },
        toggleStoryViewMode: (state) => {
            state.storyViewMode = !state.storyViewMode;
        },
    },
    extraReducers: (builder) => {
        builder.addCase(generateImage.fulfilled, (state, action) => {
            const newNode = action.payload;
            if (!state.appContext) { // First node created
                 state.appContext = newNode.id;
            } else if (newNode.context === 'sequential') {
                state.appContext = newNode.id;
            }
        });
        builder.addCase(nodeSlice.actions.addNode, (state, action) => {
             if (!state.appContext) {
                 state.appContext = action.payload.id;
             }
        });
    }
});

export const { addNode } = nodeSlice.actions;
export const { setAppContext, toggleViewMode, toggleStoryViewMode } = appSlice.actions;


// Store
const store = configureStore({
    reducer: {
        nodes: nodeSlice.reducer,
        app: appSlice.reducer,
    },
});

type RootState = ReturnType<typeof store.getState>;
type AppDispatch = typeof store.dispatch;
const useAppDispatch = () => useDispatch<AppDispatch>();


// --- 4. REACT COMPONENTS ---

const styles = {
    panel: {
        backgroundColor: 'var(--color-bg-secondary)',
        border: '1px solid var(--color-border-primary)',
        borderRadius: '6px',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
    },
    panelHeader: {
        padding: '8px 12px',
        backgroundColor: 'var(--color-bg-tertiary)',
        borderBottom: '1px solid var(--color-border-primary)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        fontSize: '12px',
        fontWeight: '600',
        color: 'var(--color-text-secondary)',
    },
    panelContent: {
        padding: '16px',
        flex: 1,
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
    },
    iconButton: {
        background: 'none',
        border: 'none',
        color: 'var(--color-text-secondary)',
        cursor: 'pointer',
        padding: '4px',
        borderRadius: '4px',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    emptyState: {
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--color-text-secondary)',
        fontSize: '14px',
    }
};

const EnhancedCard = ({ node }: { node: Node }) => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>{node.name}</span>
            <div style={{ border: '1px solid var(--color-border-primary)', padding: '4px', borderRadius: '6px', backgroundColor: 'var(--color-bg-tertiary)' }}>
                <img src={node.image} alt={node.name} style={{ width: '256px', height: '256px', objectFit: 'cover', borderRadius: '4px', display: 'block' }}/>
            </div>
        </div>
    );
};


const Story = () => {
    const dispatch = useAppDispatch();
    const { storyViewMode, appContext } = useSelector((state: RootState) => state.app);
    const { nodes } = useSelector((state: RootState) => state.nodes);

    const history = useMemo(() => {
        if (!appContext || !nodes[appContext]) return [];
        const historyTrail: Node[] = [];
        let currentNodeId: string | null = appContext;
        while(currentNodeId) {
            historyTrail.unshift(nodes[currentNodeId]);
            currentNodeId = nodes[currentNodeId].parentId;
        }
        return historyTrail;
    }, [appContext, nodes]);


    return (
        <div style={{...styles.panel, minWidth: '300px', width: '25%'}}>
            <div style={styles.panelHeader}>
                <span>STORY</span>
                 {history.length > 0 && (
                    <button style={styles.iconButton} onClick={() => dispatch(toggleStoryViewMode())}>
                        {storyViewMode ? <EyeSlashIcon/> : <EyeIcon/>}
                    </button>
                 )}
            </div>
            <div style={styles.panelContent}>
                {history.length === 0 ? (
                    <div style={styles.emptyState}>Nothing to display...</div>
                ) : (
                    <div>
                        {history.map((node, index) => (
                           <div key={node.id} style={{ marginBottom: '12px', fontSize: '14px', display: 'flex', alignItems: 'flex-start' }}>
                               {storyViewMode && node.context === 'iterative' && index > 0 && <span style={{marginRight: '8px', color: 'var(--color-text-secondary)'}}><PlusIcon /></span>}
                               <div style={{ flex: 1 }}>
                                   <p style={{ margin: 0, padding: '4px', borderRadius: '4px', hover: { backgroundColor: 'var(--color-bg-tertiary)'} }}>
                                       {node.promptString}
                                   </p>
                                   {storyViewMode && index > 0 && (
                                     <button 
                                         onClick={() => dispatch(setAppContext(node.id))}
                                         style={{...styles.iconButton, fontSize: '12px', color: 'var(--color-accent)', padding: '0', marginTop: '4px' }}
                                     >
                                         {node.name}
                                     </button>
                                   )}
                               </div>
                           </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

const Prompt = () => {
    const [input, setInput] = useState('');
    const dispatch = useAppDispatch();
    const status = useSelector((state: RootState) => state.nodes.status);

    const handleSend = () => {
        if (input.trim() && status !== 'loading') {
            dispatch(generateImage(input.trim()));
            setInput('');
        }
    }

    return (
        <div style={{ padding: '10px', borderTop: '1px solid var(--color-border-primary)', backgroundColor: 'var(--color-bg-secondary)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', border: '1px solid var(--color-border-primary)', borderRadius: '6px', padding: '4px 8px', backgroundColor: 'var(--color-bg-primary)'}}>
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type..."
                    style={{
                        flex: 1,
                        background: 'none',
                        border: 'none',
                        outline: 'none',
                        color: 'var(--color-text-primary)',
                        fontSize: '14px',
                        padding: '8px 0',
                    }}
                    disabled={status === 'loading'}
                />
                <button 
                    onClick={handleSend}
                    disabled={!input.trim() || status === 'loading'}
                    style={{...styles.iconButton, color: 'var(--color-accent)', cursor: (!input.trim() || status === 'loading') ? 'not-allowed' : 'pointer' }}
                >
                    {status === 'loading' ? <LoadingSpinner /> : <SendIcon />}
                </button>
            </div>
        </div>
    );
};


const Views = () => {
    const dispatch = useAppDispatch();
    const { appContext, viewMode } = useSelector((state: RootState) => state.app);
    const { nodes } = useSelector((state: RootState) => state.nodes);
    const workingNode = appContext ? nodes[appContext] : null;

    return (
        <div style={{...styles.panel, flex: 1}}>
            <div style={styles.panelHeader}>
                <span>VIEWS</span>
                {workingNode && (
                     <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div className="tooltip">
                            <button style={styles.iconButton}><EyeIcon /></button>
                            <span className="tooltiptext">Show reference files</span>
                        </div>
                        <div className="tooltip">
                            <button style={styles.iconButton} onClick={() => dispatch(toggleViewMode())}>
                                {viewMode === 'iterative' ? <IterativeIcon /> : <SequentialIcon />}
                            </button>
                            <span className="tooltiptext">Change context</span>
                        </div>
                         <div className="tooltip">
                            <button style={styles.iconButton}><SearchIcon /></button>
                            <span className="tooltiptext">Search nodes</span>
                        </div>
                    </div>
                )}
            </div>
            <div style={{ ...styles.panelContent, justifyContent: 'center', alignItems: 'center' }}>
                {workingNode ? <EnhancedCard node={workingNode} /> : (
                    <div style={styles.emptyState}>Nothing to display...</div>
                )}
            </div>
        </div>
    );
};

const Map = () => {
    const { nodes, rootNodeId } = useSelector((state: RootState) => state.nodes);
    const nodeCount = Object.keys(nodes).length;
    
    return (
        <div style={{...styles.panel, minWidth: '300px', width: '25%'}}>
            <div style={styles.panelHeader}>
                <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                    <span>MAP</span>
                    {nodeCount > 0 && <span style={{fontSize: '10px', backgroundColor: 'var(--color-bg-tertiary)', padding: '2px 6px', borderRadius: '10px'}}>{nodeCount} node{nodeCount > 1 ? 's' : ''}</span>}
                </div>
            </div>
            <div style={styles.panelContent}>
                {nodeCount === 0 ? (
                     <div style={styles.emptyState}>Nothing to display...</div>
                ) : (
                    <div style={{fontSize: '12px'}}>
                      {
                        // FIX: Explicitly type `node` as `Node` to fix TypeScript error where `node` was inferred as `unknown`.
                        Object.values(nodes).map((node: Node) => <div key={node.id}>{node.name}</div>)
                      }
                    </div>
                )}
            </div>
        </div>
    );
};


const App = () => {
    return (
        <Provider store={store}>
            <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
                <div style={{ display: 'flex', flex: 1, padding: '10px', gap: '10px', overflow: 'hidden' }}>
                    <Story />
                    <Views />
                    <Map />
                </div>
                <Prompt />
            </div>
        </Provider>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
