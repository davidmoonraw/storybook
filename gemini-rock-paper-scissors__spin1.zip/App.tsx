import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import useAuth from './hooks/useAuth';
import Header from './components/Header';
import ProtectedRoute from './components/ProtectedRoute';

// Lazy load pages for better performance
const SignIn = React.lazy(() => import('./pages/SignIn'));
const SignUp = React.lazy(() => import('./pages/SignUp'));
const Game = React.lazy(() => import('./pages/Game'));
const Leaderboard = React.lazy(() => import('./pages/Leaderboard'));

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

const AppContent: React.FC = () => {
  const { user } = useAuth();

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col bg-base-100 text-base-content dark:bg-neutral">
        <Header />
        <main className="flex-grow container mx-auto p-4 md:p-8 flex items-center justify-center">
          <React.Suspense fallback={<div className="text-center text-lg animate-pulse">Loading...</div>}>
            <Routes>
              <Route path="/signin" element={user ? <Navigate to="/game" /> : <SignIn />} />
              <Route path="/signup" element={user ? <Navigate to="/game" /> : <SignUp />} />
              <Route path="/game" element={<ProtectedRoute><Game /></ProtectedRoute>} />
              <Route path="/leaderboard" element={<ProtectedRoute><Leaderboard /></ProtectedRoute>} />
              <Route path="/" element={<Navigate to="/game" />} />
              <Route path="*" element={<Navigate to="/game" />} />
            </Routes>
          </React.Suspense>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
