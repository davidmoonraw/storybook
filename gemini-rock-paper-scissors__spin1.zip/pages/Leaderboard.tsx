import React, { useState, useEffect } from 'react';

interface Score {
  wins: number;
  losses: number;
  draws: number;
}

interface LeaderboardEntry {
  username: string;
  score: Score;
}

const Leaderboard: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    // Mock fetching leaderboard data from localStorage
    const scores = JSON.parse(localStorage.getItem('scores') || '{}');
    const sortedLeaderboard = Object.keys(scores)
      .map(username => ({
        username,
        score: scores[username],
      }))
      .sort((a, b) => b.score.wins - a.score.wins || a.score.losses - b.score.losses); // Sort by wins, then by losses

    setLeaderboard(sortedLeaderboard);
  }, []);

  const getTrophy = (index: number) => {
    if (index === 0) return '🏆';
    if (index === 1) return '🥈';
    if (index === 2) return '🥉';
    return `#${index + 1}`;
  };

  return (
    <div className="w-full max-w-2xl mx-auto animate-slide-in">
      <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-lg overflow-hidden">
        <div className="p-6 bg-primary dark:bg-secondary">
          <h1 className="text-3xl font-bold text-center text-white">Leaderboard</h1>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm font-light">
            <thead className="border-b font-medium bg-gray-100 dark:border-neutral-500 dark:bg-gray-700">
              <tr>
                <th scope="col" className="px-6 py-4">Rank</th>
                <th scope="col" className="px-6 py-4">Player</th>
                <th scope="col" className="px-6 py-4 text-center text-green-500">Wins</th>
                <th scope="col" className="px-6 py-4 text-center text-red-500">Losses</th>
                <th scope="col" className="px-6 py-4 text-center text-yellow-500">Draws</th>
              </tr>
            </thead>
            <tbody>
              {leaderboard.map((entry, index) => (
                <tr key={entry.username} className="border-b transition duration-300 ease-in-out hover:bg-gray-50 dark:border-neutral-500 dark:hover:bg-neutral-600">
                  <td className="whitespace-nowrap px-6 py-4 font-bold text-lg">{getTrophy(index)}</td>
                  <td className="whitespace-nowrap px-6 py-4 font-medium">{entry.username}</td>
                  <td className="whitespace-nowrap px-6 py-4 text-center">{entry.score.wins}</td>
                  <td className="whitespace-nowrap px-6 py-4 text-center">{entry.score.losses}</td>
                  <td className="whitespace-nowrap px-6 py-4 text-center">{entry.score.draws}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {leaderboard.length === 0 && (
          <p className="p-6 text-center text-gray-500 dark:text-gray-400">No games played yet. Be the first to set a score!</p>
        )}
      </div>
    </div>
  );
};

export default Leaderboard;
