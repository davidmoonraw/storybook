import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import useAuth from '../hooks/useAuth';

type Choice = 'Rock' | 'Paper' | 'Scissors';
const choices: Choice[] = ['Rock', 'Paper', 'Scissors'];

interface Score {
  wins: number;
  losses: number;
  draws: number;
}

const Game: React.FC = () => {
  const [playerChoice, setPlayerChoice] = useState<Choice | null>(null);
  const [aiChoice, setAiChoice] = useState<Choice | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState<Score>({ wins: 0, losses: 0, draws: 0 });

  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      // Load user's score from localStorage
      const allScores = JSON.parse(localStorage.getItem('scores') || '{}');
      if (allScores[user.username]) {
        setScore(allScores[user.username]);
      }
    }
  }, [user]);

  const updateScore = (newScore: Score) => {
    setScore(newScore);
    if (user) {
      const allScores = JSON.parse(localStorage.getItem('scores') || '{}');
      allScores[user.username] = newScore;
      localStorage.setItem('scores', JSON.stringify(allScores));
    }
  };

  const getEmoji = (choice: Choice | null) => {
    if (choice === 'Rock') return '✊';
    if (choice === 'Paper') return '✋';
    if (choice === 'Scissors') return '✌️';
    return '❔';
  };

  const playGame = async (choice: Choice) => {
    setPlayerChoice(choice);
    setAiChoice(null);
    setResult(null);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Let's play Rock, Paper, Scissors. I choose ${choice}. You must choose one of Rock, Paper, or Scissors.`,
        config: {
          systemInstruction: "You are a highly competitive Rock, Paper, Scissors opponent. You will analyze the user's choice and make a strategic counter-move. Your response must be only one word: 'Rock', 'Paper', or 'Scissors'.",
          temperature: 1, // Maximize randomness for unpredictability
          topK: 3,
        },
      });

      const aiResponseText = response.text.trim();
      
      let finalAiChoice: Choice | null = null;
      if (choices.includes(aiResponseText as Choice)) {
        finalAiChoice = aiResponseText as Choice;
      } else {
        // Fallback if Gemini doesn't respond with a valid choice
        finalAiChoice = choices[Math.floor(Math.random() * choices.length)];
      }
      
      setAiChoice(finalAiChoice);
      determineWinner(choice, finalAiChoice);

    } catch (error) {
      console.error("Error calling Gemini API:", error);
      // Fallback to random choice on API error
      const randomAiChoice = choices[Math.floor(Math.random() * choices.length)];
      setAiChoice(randomAiChoice);
      determineWinner(choice, randomAiChoice);
      setResult("AI is thinking... but I'll choose for it! Let's see who won.");
    } finally {
      setLoading(false);
    }
  };

  const determineWinner = (player: Choice, ai: Choice) => {
    let newScore = { ...score };
    if (player === ai) {
      setResult("It's a Draw!");
      newScore.draws++;
    } else if (
      (player === 'Rock' && ai === 'Scissors') ||
      (player === 'Paper' && ai === 'Rock') ||
      (player === 'Scissors' && ai === 'Paper')
    ) {
      setResult('You Win! 🎉');
      newScore.wins++;
    } else {
      setResult('You Lose! 🤖');
      newScore.losses++;
    }
    updateScore(newScore);
  };

  return (
    <div className="w-full max-w-3xl text-center animate-fade-in">
      <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-lg p-8">
        <h1 className="text-4xl font-extrabold mb-2 text-primary dark:text-secondary">Choose your weapon!</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-6">Your Score: <span className="text-green-500 font-bold">{score.wins}</span> Wins, <span className="text-red-500 font-bold">{score.losses}</span> Losses, <span className="text-yellow-500 font-bold">{score.draws}</span> Draws</p>

        <div className="flex justify-around items-center my-10">
          <div className="text-center">
            <h2 className="text-2xl font-semibold mb-4">You</h2>
            <div className={`text-8xl p-6 rounded-full transition-all duration-300 ${playerChoice ? 'bg-blue-100 dark:bg-blue-900 scale-110' : 'bg-gray-200 dark:bg-gray-700'}`}>
              {getEmoji(playerChoice)}
            </div>
          </div>
          <div className="text-4xl font-bold text-neutral dark:text-gray-200">VS</div>
          <div className="text-center">
            <h2 className="text-2xl font-semibold mb-4">Gemini AI</h2>
            <div className={`text-8xl p-6 rounded-full transition-all duration-300 ${aiChoice ? 'bg-orange-100 dark:bg-orange-900 scale-110' : 'bg-gray-200 dark:bg-gray-700'}`}>
              {loading ? <span className="animate-pulse-strong">...</span> : getEmoji(aiChoice)}
            </div>
          </div>
        </div>

        {result && <h2 className={`text-4xl font-bold my-6 animate-slide-in ${result.includes('Win') ? 'text-accent' : result.includes('Lose') ? 'text-red-500' : 'text-gray-500'}`}>{result}</h2>}

        <div className="flex justify-center gap-4 md:gap-8 mt-8">
          {choices.map((choice) => (
            <button
              key={choice}
              onClick={() => playGame(choice)}
              disabled={loading}
              className="bg-secondary text-white font-bold p-4 rounded-full text-5xl transition-transform transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-orange-300 disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label={`Choose ${choice}`}
            >
              {getEmoji(choice)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Game;
