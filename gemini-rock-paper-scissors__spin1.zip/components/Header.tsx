import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/signin');
  };

  return (
    <header className="bg-primary text-white shadow-md">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/game" className="text-2xl font-bold tracking-tight">
          Rock Paper Scissors
        </Link>
        <div className="flex items-center space-x-4">
          {user ? (
            <>
              <Link to="/game" className="hover:text-secondary transition-colors">Game</Link>
              <Link to="/leaderboard" className="hover:text-secondary transition-colors">Leaderboard</Link>
              <span className="font-semibold">Hi, {user.username}!</span>
              <button
                onClick={handleLogout}
                className="bg-secondary hover:bg-orange-600 text-white font-bold py-2 px-4 rounded transition-transform transform hover:scale-105"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/signin" className="hover:text-secondary transition-colors">Sign In</Link>
              <Link to="/signup" className="hover:text-secondary transition-colors">Sign Up</Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;
